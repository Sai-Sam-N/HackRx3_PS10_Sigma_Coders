import pandas as pd
import numpy as np


Travel = pd.read_csv("Travel.csv")
two_wheelers = pd.read_csv("2W.csv")
four_wheelers = pd.read_csv("4W.csv")
brand_terms = pd.read_csv("BrandTerms.csv")
Health = pd.read_csv("Health.csv")

def removeSplChars(test_string):
    bad_chars = [';', ':', '!', "*", '"',"[","]","+"]
    act_str = test_string
    for i in bad_chars :
        act_str = act_str.replace(i, '')
    return str(act_str)

def MakeArray(col):
    Arr_col = col.to_numpy()
    Arr = []
    for i in Arr_col:
        q = removeSplChars(i)
        Arr.append(q)
    Arr = np.array(Arr)
    
    # Refining
    Arr_cleaned = []
    for word in Arr:
        p = [str(word) for word in word.split()]
        for i in p:
            Arr_cleaned.append(i)
    
    # Removing Duplicates
    Arr_cleaned2 = set(Arr_cleaned)
    Arr_cleaned2 = list(Arr_cleaned2)
    
    # Converting data into lower
    for i in range(len(Arr_cleaned2)):
        Arr_cleaned2[i] = Arr_cleaned2[i].lower()
    
    return Arr_cleaned2


Travel_cleaned = MakeArray(Travel["Terms"])
two_wheelers_cleaned = MakeArray(two_wheelers["Terms"])
four_wheelers_cleaned = MakeArray(four_wheelers["Terms"])
brand_terms_cleaned = MakeArray(brand_terms["Terms"])
Health_cleaned = MakeArray(Health["Terms"])

import nltk
# nltk.download('stopwords')

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

def RemoveStopWords(col):
    stop_words = set(stopwords.words('english'))
    filtered = []
    for i in col:
        if i in stop_words:
            continue
        filtered.append(i)
    return filtered

Travel_cleaned2 = RemoveStopWords(Travel_cleaned)
two_wheelers_cleaned2 = RemoveStopWords(two_wheelers_cleaned)
four_wheelers_cleaned2 = RemoveStopWords(four_wheelers_cleaned)
brand_terms_cleaned2 = RemoveStopWords(brand_terms_cleaned)
Health_cleaned2 = RemoveStopWords(Health_cleaned)

data2 = pd.concat([pd.Series(Travel_cleaned2,name='Travel'),pd.Series(two_wheelers_cleaned2,name='2W'),pd.Series(four_wheelers_cleaned2,name='4W'),pd.Series(brand_terms_cleaned2,name='Brand Terms'),pd.Series(Health_cleaned2,name='2W')], axis=1)

def recommend(word):
    flag = False
    counter = 0
    if word in Travel_cleaned2:
        flag = True
        counter = 1
    if word in two_wheelers_cleaned2:
        flag = True
        counter = 2
    if word in four_wheelers_cleaned2:
        flag = True
        counter = 3
    if word in brand_terms_cleaned2:
        flag = True
        counter = 4
    if word in Health_cleaned2:
        flag = True
        counter = 5
    return (flag,counter)

from difflib import SequenceMatcher

def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()

def Similarity(T,w):
    for i in T:
        if similar(i,w) >= 0.8:
            return True
    return False

BroadLabels = {
    'Travel' : 1,
    'Two Wheelers' : 2,
    'Four Wheelers' : 3,
    'Brand Insurance' :4,
    'Health Insurance' : 5
}

def PrimaryFiltering(word):
    fl = False
    cn = 0
    
    # When flag is false, Similarity based matching of keys is done
    lst = [] #list of relevant recommendations
    if Similarity(Travel_cleaned2,word):
        cn = 1
        lst.append(cn)
        fl = True
    if Similarity(two_wheelers_cleaned2,word):
        cn = 2
        lst.append(cn)
        fl = True
    if Similarity(four_wheelers_cleaned2,word):
        cn = 3
        lst.append(cn)
        fl = True
    if Similarity(brand_terms_cleaned2,word):
        cn = 4
        lst.append(cn)
        fl = True
    if Similarity(Health_cleaned2,word):
        cn = 5
        lst.append(cn)
        fl = True    
    return (lst,fl) # Return whether primary filter is success or failure           

TravelSpecific = pd.read_csv("Act_Travel.csv",encoding='cp1252')
TwoWSpecific = pd.read_csv("Act_2W.csv",encoding='cp1252')
FourWSpecific = pd.read_csv("Act_4W.csv",encoding='cp1252')
HealthSpecific = pd.read_csv("Act_Health.csv",encoding='cp1252')

for i in TravelSpecific.columns:
    TravelSpecific[i].str.lower()
    
for i in TwoWSpecific.columns:
    TwoWSpecific[i].str.lower()
    
for i in FourWSpecific.columns:
    FourWSpecific[i].str.lower()
    
for i in HealthSpecific.columns:
    HealthSpecific[i].str.lower()

# Making a huge list of dictionaries
TSDict = {}
for i in TravelSpecific.columns:
    a = list(TravelSpecific[i].dropna())
    TSDict[i] = a

TwoSDict = {}
for i in TwoWSpecific.columns:
    a = list(TwoWSpecific[i].dropna())
    TwoSDict[i] = a
    
FSDict = {}
for i in FourWSpecific.columns:
    a = list(FourWSpecific[i].dropna())
    FSDict[i] = a
    
HSDict = {}
for i in HealthSpecific.columns:
    a = list(HealthSpecific[i].dropna())
    HSDict[i] = a
    
def SecondaryFiltering(word):
    res = []
    flg = False
    
    for key in TSDict:
        if word in TSDict[key]:
            res.append(key)
            flg = True
            
    for key in TwoSDict:
        if word in TwoSDict[key]:
            res.append(key)
            flg = True
            
    for key in FSDict:
        if word in FSDict[key]:
            res.append(key)
            flg = True
            
    for key in HSDict:
        if word in HSDict[key]:
            res.append(key)
            flg = True
    return (res,flg)

Links = pd.read_csv("InsuranceLinks.csv", encoding='cp1252')

Links.set_index('Insurance Name', inplace=True) #Setting index as insurance names

Links['counter'] = 0 # Adding a counter column to find the frequency

def IncrementCounter(Name):
    if Links["Website"][Name]:
        cnt = Links['counter'][Name] 
        cnt = cnt + 1 # Increment
        Links.at[Name,'counter'] = cnt

Connection = pd.read_csv("BroadNSpecs.csv",encoding='cp1252')
ColNames2 = Connection.columns
Conn_Dict = {}
for i in ColNames2:
    a = list(Connection[i].dropna())
    Conn_Dict[i] = a

def FindKey(tag):
    for key in Conn_Dict:
        if tag in Conn_Dict[key]:
            return key

def SpecificSuggestion(l):
    recommendedLinks = []
    for i in l:
        #print(f"{i} --> {Links['Website'][i]}")
        # print(Links['Website'][i])
        recommendedLinks.append(Links['Website'][i])
    print( recommendedLinks)

def FindCounter(Col):
    return Links['counter'][Col] 

def SortIndex(TotLinks):
        CounterVal = []
        for i in TotLinks:
            ind = FindCounter(i)
            CounterVal.append(ind)
        # Sorting TotLinks wrt CounterVal
        SortedLinks = [x for _,x in sorted(zip(CounterVal,TotLinks), reverse = True)]
        return SortedLinks

def CalcTrends():
    Complete_Links = list(Links.index)
    Trends_Links = SortIndex(Complete_Links)
    return Trends_Links

def FindBroadIndex(tag):
    for key in BroadLabels:
        if BroadLabels[key] == tag:
            return key

# Editing
def Case3(Lst): # PFF = False and SFF = True -> go specific + back track    
    primary_index = Lst[0]
    secondary_index = Lst[1]
    ActLinks = [] # The actual ones
    TotLinks = [] # The excess ones apart from the ones we know
    Keys = [] # Whatever keys we've got
    
    # Adding Actual Links
    for i in secondary_index:
        if i != None:
            ActLinks.append(i)
            
            
    if ActLinks == []:
        # Adding Actual Links
        r = []
        for i in primary_index:
            if i != None:
                x = FindBroadIndex(i)
                r.append(x)
        for i in r:
            z = FindKey(i)
            Keys.append(z)
            
        for j in Keys:
            ActLinks.append(Conn_Dict[i])
   
    ActResult = SortIndex(ActLinks)
    
    if secondary_index != []:
        if len(secondary_index) > 1:
            for i in range(len(secondary_index)):
                q = FindKey(secondary_index[i])
                Keys.append(q)

            # Add corresponding sub-headings
            for i in Keys:
                a = Conn_Dict[i]
                for j in a:
                    TotLinks.append(j)

        elif len(secondary_index) == 1:
            Keys = FindKey(secondary_index)
            if Keys != None:
                TotLinks = Conn_Dict[Keys]
            else:
                TotLinks = CalcTrends()
        TotLinks = set(TotLinks)
        Result = SortIndex(TotLinks)
        
    elif primary_index != []:
        if len(primary_index) > 1:
            # get the broad keys
            for i in range(len(primary_index)):
                for key in BroadLabels:
                    if BroadLabels[key] == primary_index:
                        Keys.append(key)
                        TotLinks.append(Conn_Dict[key])
                    else:
                        return False
                    
            # get specific keys
            for i in Keys:
                a = Conn_Dict[i]
                for j in a:
                    TotLinks.append(j)
            
        elif len(primary_index) == 1:
            for key in BroadLabels:
                if BroadLabels[key] == primary_index:
                    Keys = key
                    TotLinks = Conn_Dict[key]
                    if Keys == None:
                        TotLinks = CalcTrends()
        TotLinks = set(TotLinks)
        Result = SortIndex(TotLinks)
        
    else:
        ActResult = CalcTrends()
    return (ActResult,Result)
        

def Recommendation_Engine(word): # Complete recommender system    
    (First_ans,PFF) = PrimaryFiltering(word) # Primary Filtering Flag
    (Sec_ans,SFF) = SecondaryFiltering(word) # Secondary Filtering Flase
    
    if word in brand_terms_cleaned2:
        PN = CalcTrends()
        SpecificSuggestion(PN[0])
        SpecificSuggestion(PN[1])
        # SpecificSuggestion(PN)
    elif (PFF == True) and (SFF == True):
        PN = Case3((First_ans,Sec_ans))
        SpecificSuggestion(PN[0])
        SpecificSuggestion(PN[1])
        # SpecificSuggestion(PN)
    elif (PFF == True) and (SFF == False):
        PN = Case3((First_ans,Sec_ans))
        SpecificSuggestion(PN[0])
        SpecificSuggestion(PN[1])
        # SpecificSuggestion(PN)
    elif (PFF == False) and (SFF == True):
        PN = Case3((First_ans,Sec_ans))
        SpecificSuggestion(PN[0])
        SpecificSuggestion(PN[1])
        # SpecificSuggestion(PN)
    elif (PFF == False) and (SFF == False):
        PN = Case3((First_ans,Sec_ans))
        SpecificSuggestion(PN[0])
        SpecificSuggestion(PN[1])
        # SpecificSuggestion(PN)
    else:
        PN = CalcTrends()
        SpecificSuggestion(PN[0])
        SpecificSuggestion(PN[1])
        # SpecificSuggestion(PN)

Recommendation_Engine("")

