import tkinter as tk
from tkinter import messagebox
from textblob import TextBlob
import webbrowser
from Recommendation_Engine3 import *
    
def create_window():
    window = tk.Tk()

    window.geometry("540x627+502+123")
    window.resizable(0, 0)
    window.title("Bajaj Recommendation Engine")
    window.configure(background="#e7eaf6")
    
    
#------------------------Variables------------------------------      
    searchQuery = tk.StringVar()
    
#------------------------Status Label------------------------------ 
    lab_status = tk.Label(window)
    lab_status.place(relx=0.019, rely=0.933, height=31, width=524)
    lab_status.configure(background="#e7eaf6")
    lab_status.configure(font="-family {Arial} -size 10 -weight bold")
    lab_status.configure(foreground="red")
    lab_status.configure(text='''---''')
    
#------------------------Functions------------------------------  
    def exitt():
        window.destroy()
    
    def helpp():
        messagebox.showinfo(
                "How to Operate",
                '''      
                Enter a search query and click on Search button.
                Click on the Clear button to reset the search bar''')
                
    def about():
        messagebox.showinfo(
                'About','''
                    Bajaj Recommendation Engine
                    Version : 1.0
                    Last Update : 25/06/2022
                    ''')
                    
    def clear():
        searchQuery.set('')
        lab_status.configure(text = '---')
    
    def search():
        searchQueryCorrected = TextBlob(searchQuery.get())
        searchQueryCorrected = searchQueryCorrected.correct()
        # searchQuery.set(searchQueryCorrected)
        Recommendation_Engine(searchQueryCorrected)

#------------------------Menu------------------------------             
    menubar = tk.Menu(window)
    window.configure(menu = menubar)

    file = tk.Menu(menubar)
    file.add_command(label="Exit",command = exitt)
    menubar.add_cascade(menu=file,label="File")
    
    option = tk.Menu(menubar)
    option.add_command(label="About",command = about)
    option.add_command(label="Help",command = helpp)
    menubar.add_cascade(menu=option,label="Options")
    
#------------------------Labels------------------------------             
    label_0 = tk.Label(window)
    label_0.place(relx=0.13, rely=0.01, height=50, width=411)
    label_0.configure(background="#e7eaf6")
    label_0.configure(font="-family {Arial} -size 14 -weight bold -slant italic")
    label_0.configure(foreground="#1089ff")
    label_0.configure(text='''Welcome to Bajaj Recommendation Engine''')
    label_0.configure(relief = 'solid')
    
#------------------------Entry------------------------------             
    entry_search = tk.Entry(window)
    entry_search.place(relx=0.05, rely=0.15, height=30, relwidth=0.9)
    entry_search.configure(background="white")
    entry_search.configure(foreground="#000000")
    entry_search.configure(textvariable=searchQuery)

#------------------------Button------------------------------  
    but_search = tk.Button(window)
    but_search.place(relx=0.15, rely=0.25, height=44, width=127)
    but_search.configure(background="#1089ff")
    but_search.configure(font="-family {Arial} -size 12 -weight bold")
    but_search.configure(foreground="white")
    but_search.configure(text='''Search''')
    but_search.configure(command = search)
    
    but_clear = tk.Button(window)
    but_clear.place(relx=0.60, rely=0.25, height=44, width=127)
    but_clear.configure(background="#1089ff")
    but_clear.configure(font="-family {Arial} -size 12 -weight bold")
    but_clear.configure(foreground="white")
    but_clear.configure(text='''Clear''')
    but_clear.configure(command = clear)

#------------------------Listbox------------------------------  
    def weblink(arg):
        index = results.curselection()
        item = results.get(index)
        if 'https://' in item:
            webbrowser.open_new(item)
    
    list_of_items = ['Google news',
                     'https://www.google.com/',
                     'https://news.yahoo.com/',
                     'Yahoo news'
                     ]
    
    results = tk.Listbox(window)
    results.bind('<<ListboxSelect>>', weblink)
    for i in range(len(list_of_items)):
        results.insert(i, list_of_items[i])
    results.place(relx=0.1, rely=0.4, relheight=0.5, relwidth=0.8)
    
    
    
    window.mainloop()
    return None

if __name__ == '__main__':
    create_window()