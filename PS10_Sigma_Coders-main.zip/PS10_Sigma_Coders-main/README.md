# PS10_Sigma_Coders - RECOMMENDATION ENGINE

## Team Mates
1. S Gopi
2. Vishvajeet Ravelkar
3. Sai Samyuktha N
4. Rishiraj Sarit Biswas
5. Altaf Khan


## Problem Statement
Our aim is to suggest/recommend keywords that are more relevant to user’s search query. This algorithm will help us to improve search results.

## Overview Of Solution 
By using Machine Learning and Deep Learning we’ll try to learn, analyse and interpret user’s current interests, sentiments, mood etc and we’ll recommend similar keywords and results accoding to his search queryusing our recommendation engine.




